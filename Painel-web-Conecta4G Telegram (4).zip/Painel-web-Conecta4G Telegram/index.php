<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/login.php");
if (getLogged($sid) == true) {
	header("location: home.php");
} else {
?>

	<section class="vh-lg-100 mt-5 mt-lg-0 bg-soft d-flex align-items-center">
		<div class="container">
			<div class="row justify-content-center form-bg-image">
				<div class="col-12 d-flex align-items-center justify-content-center">
					<div class="bg-white shadow border-0 rounded border-light p-4 p-lg-5 w-100 fmxw-500">
						<div class="text-center text-md-center mb-4 mt-md-0">
							<h1 class="mb-0 h3">Painel Conecta4G</h1>
						</div>
						<?php
						if (isset($_SESSION['erro'])) : echo $_SESSION['erro'];
							session_destroy();
						endif; ?>
						<form action="" method="POST" class="mt-4">
							<!-- Form -->
							<div class="form-group mb-4">
								<label for="email">Usuário</label>
								<div class="input-group">
									<span class="input-group-text" id="basic-addon1">
										<svg class="icon icon-xs text-gray-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
											<path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"></path>
											<path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"></path>
										</svg>
									</span>
									<input type="text" class="form-control" placeholder="Usuário" name="login" autofocus required>
								</div>
							</div>
							<!-- End of Form -->
							<div class="form-group">
								<!-- Form -->
								<div class="form-group mb-4">
									<label for="password">Senha</label>
									<div class="input-group">
										<span class="input-group-text" id="basic-addon2">
											<svg class="icon icon-xs text-gray-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
												<path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"></path>
											</svg>
										</span>
										<input type="password" placeholder="Senha" class="form-control" name="senha" required>
									</div>
								</div>
								<!-- End of Form -->
								<div class="d-flex justify-content-between align-items-top mb-4">
									<div class="form-check">
										<input class="form-check-input" type="checkbox" value="" id="remember">
										<label class="form-check-label mb-0" for="remember">
											Lembre-me
										</label>
									</div>
									<div></div>
								</div>
							</div>
							<div class="d-grid">
								<button type="submit" name="btn_login" class="btn btn-gray-800">Entrar</button>
							</div>
						</form>
						<div class="d-flex justify-content-center align-items-center mt-4">
							<span class="fw-normal">
								Desenvolvido e melhorado by
								<a href="https://coutyssh.com.br" class="fw-bold">CoutySSH</a>

</a>
<script type="text/javascript">(function() {var script=document.createElement("script");script.type="text/javascript";script.async =true;script.src="//telegram.im/widget-button/index.php?id=@Couty_SSH";document.getElementsByTagName("head")[0].appendChild(script);})();</script>
<script type="text/javascript">(function() {var script=document.createElement("script");script.type="text/javascript";script.async =true;script.src="//telegram.im/widget-button/index.php?id=@Couty_SSH";document.getElementsByTagName("head")[0].appendChild(script);})();</script>
<script type="text/javascript">(function() {var script=document.createElement("script");script.type="text/javascript";script.async =true;script.src="//telegram.im/widget-button/index.php?id=@Couty_SSH";document.getElementsByTagName("head")[0].appendChild(script);})();</script>
<script type="text/javascript">(function() {var script=document.createElement("script");script.type="text/javascript";script.async =true;script.src="//telegram.im/widget-button/index.php?id=@Couty_SSH";document.getElementsByTagName("head")[0].appendChild(script);})();</script>
<script type="text/javascript">(function() {var script=document.createElement("script");script.type="text/javascript";script.async =true;script.src="//telegram.im/widget-button/index.php?id=@Couty_SSH";document.getElementsByTagName("head")[0].appendChild(script);})();</script>
<script type="text/javascript">(function() {var script=document.createElement("script");script.type="text/javascript";script.async =true;script.src="//telegram.im/widget-button/index.php?id=@Couty_SSH";document.getElementsByTagName("head")[0].appendChild(script);})();</script>
<script type="text/javascript">(function() {var script=document.createElement("script");script.type="text/javascript";script.async =true;script.src="//telegram.im/widget-button/index.php?id=@Couty_SSH";document.getElementsByTagName("head")[0].appendChild(script);})();</script>
<script type="text/javascript">(function() {var script=document.createElement("script");script.type="text/javascript";script.async =true;script.src="//telegram.im/widget-button/index.php?id=@Couty_SSH";document.getElementsByTagName("head")[0].appendChild(script);})();</script>
<a style="display:block;font-size:16px;font-weight:500;text-align:center;border-radius:8px;padding:5px;background:#389ce9;text-decoration:none;color:#fff;" href="https://t.me/Couty_SSH" target="_blank"><svg style="width:30px;height:20px;vertical-align:middle;margin:0px 5px;" viewBox="0 0 21 18"><g fill="none"><path fill="#ffffff" d="M0.554,7.092 L19.117,0.078 C19.737,-0.156 20.429,0.156 20.663,0.776 C20.745,0.994 20.763,1.23 20.713,1.457 L17.513,16.059 C17.351,16.799 16.62,17.268 15.88,17.105 C15.696,17.065 15.523,16.987 15.37,16.877 L8.997,12.271 C8.614,11.994 8.527,11.458 8.805,11.074 C8.835,11.033 8.869,10.994 8.905,10.958 L15.458,4.661 C15.594,4.53 15.598,4.313 15.467,4.176 C15.354,4.059 15.174,4.037 15.036,4.125 L6.104,9.795 C5.575,10.131 4.922,10.207 4.329,10.002 L0.577,8.704 C0.13,8.55 -0.107,8.061 0.047,7.614 C0.131,7.374 0.316,7.182 0.554,7.092 Z"></path></g></svg>Telegram</a>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	</main>

<?php
}
require_once($_SERVER['DOCUMENT_ROOT'] . "/config/rodape.php"); ?>